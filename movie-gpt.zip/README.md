# movie-gpt
This is the project of Innovative Practice Course on the junior year 1st term, maybe bugs still :(
